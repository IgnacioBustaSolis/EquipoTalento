from django.apps import AppConfig


class AppestudiosConfig(AppConfig):
    name = 'AppEstudios'
